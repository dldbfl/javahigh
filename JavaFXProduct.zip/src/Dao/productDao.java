package Dao;

import java.util.List;

import Vo.productVo;

public interface productDao {

	public List<productVo> COMBO1();

	public List<productVo> COMBO2(String A);
}
