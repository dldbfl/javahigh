import java.util.ArrayList;
import java.util.List;

public class nuri {

	List a = new ArrayList();
	ArrayList b = new ArrayList();
}
