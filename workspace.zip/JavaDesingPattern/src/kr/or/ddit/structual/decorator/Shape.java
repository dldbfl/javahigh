package kr.or.ddit.structual.decorator;

public interface Shape {
	void draw();
}
