package kr.or.ddit.structual.decorator;

public class Rectangle implements Shape{

	@Override
	public void draw() {
		System.out.println("Shape : 사각형 그리기");
		
		
	}

}
