package kr.or.ddit.creational.builder;

public class Bottle implements Packing{

	@Override
	public String pack() {
		return "병패킹했서";
	}

}
