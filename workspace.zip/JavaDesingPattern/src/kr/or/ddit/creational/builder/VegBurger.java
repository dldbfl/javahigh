package kr.or.ddit.creational.builder;

public class VegBurger extends Burger{

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "야채버거";
	}

	@Override
	public float price() {
		// TODO Auto-generated method stub
		return 25.0f;
	}

}
