package kr.or.ddit.creational.builder;

public class ChickenBurger extends Burger{

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "치킨버거";
	}

	@Override
	public float price() {
		// TODO Auto-generated method stub
		return 4.0f;
	}

}
