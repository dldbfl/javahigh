package kr.or.ddit.creational.builder;

class Coke extends ColdDrink{

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "코카콜라";
	}

	@Override
	public float price() {
		// TODO Auto-generated method stub
		return 0.5f;
	}

}
