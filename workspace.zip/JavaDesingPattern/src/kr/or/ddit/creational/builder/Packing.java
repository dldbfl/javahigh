package kr.or.ddit.creational.builder;

public interface Packing {
	public String pack();
	
}
