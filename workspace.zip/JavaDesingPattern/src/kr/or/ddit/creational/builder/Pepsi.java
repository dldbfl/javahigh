package kr.or.ddit.creational.builder;

public class Pepsi extends ColdDrink {

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "Pepsi";
	}


	@Override
	public float price() {
		// TODO Auto-generated method stub
		return 0.4f;
	}

	
}
