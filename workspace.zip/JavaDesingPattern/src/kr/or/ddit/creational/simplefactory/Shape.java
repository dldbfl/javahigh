package kr.or.ddit.creational.simplefactory;

public interface Shape {
	void draw();
}
