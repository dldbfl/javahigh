package kr.or.ddit.behavioral.iterator;

public interface Iterator {
	public boolean hasNext();
	public Object next();
}
