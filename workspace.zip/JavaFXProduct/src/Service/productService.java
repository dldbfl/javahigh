package Service;

import java.util.List;

import Vo.productVo;


public interface productService {
	
	public List<productVo> COMBO1();

	public List<productVo> COMBO2(String A);
}
